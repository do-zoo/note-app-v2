const BASE_URL = "https://notes-api.dicoding.dev/v1";
export default BASE_URL;
